#pragma once

namespace crow
{
    constexpr const char VERSION[] = "master";
}
